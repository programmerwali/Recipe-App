import SwiftUI

struct FoodsGridView: View {
    let name: String

    @ObservedObject var viewModel: FoodViewViewModel
    var detailVm = DetailedViewViewModel(networking: Network())
    @AppStorage("isDarkMode") private var isDarkMode = false
    let gridItem = [GridItem(.fixed(170), spacing: 20), GridItem(.fixed(170), spacing: 20)]

    var body: some View {
        ZStack {
            Color(UIColor { traitCollection in
                // Use dynamic colors for light and dark modes
                if traitCollection.userInterfaceStyle == .dark {
                    return UIColor(red: 0.2, green: 0.3, blue: 0.5, alpha: 1.0) // Darker blue for dark mode
                } else {
                    return UIColor(red: 0.7, green: 0.8, blue: 1.0, alpha: 1.0) // Light blue for light mode
                }
            })
            .edgesIgnoringSafeArea(.all)

            ScrollView {
                LazyVGrid(columns: gridItem) {
                    ForEach(viewModel.meals, id: \.self) { meal in
                        NavigationLink(destination: DetailedView(dessertId: meal.idMeal, imageUrl: meal.strMealThumb, detailViewModel: detailVm)) {
                            CategoryCell(imageURL: meal.strMealThumb, name: meal.strMeal, sizing: 120)
                        }
                    }
                }
            }
            .onAppear() {
                viewModel.fetchFoods(name: name)
            }
        }
        .navigationTitle(name)
        .preferredColorScheme(isDarkMode ? .dark : .light)
    }
}


