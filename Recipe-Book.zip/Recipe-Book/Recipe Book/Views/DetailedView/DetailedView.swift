import SwiftUI
import CachedAsyncImage

struct DetailedView: View {
    var dessertId: String
    var imageUrl: String
    @State var selectedCategory = "Ingredienser"
    @ObservedObject var detailViewModel: DetailedViewViewModel
    @AppStorage("isDarkMode") private var isDarkMode = false

    var body: some View {
        ZStack {
            Color(UIColor { traitCollection in
                // Use dynamic colors for light and dark modes
                if traitCollection.userInterfaceStyle == .dark {
                    return UIColor(red: 0.2, green: 0.3, blue: 0.5, alpha: 1.0) // Darker blue for dark mode
                } else {
                    return UIColor(red: 0.7, green: 0.8, blue: 1.0, alpha: 1.0) // Light blue for light mode
                }
            })
            .edgesIgnoringSafeArea(.all)

            ScrollView {
                VStack(alignment: .center) {
                    Text("\(detailViewModel.recipe.name)")
                        .font(.system(size: 24, weight: .medium, design: .rounded))
                        .foregroundColor(.white)
                        .padding(.bottom)

                    CachedAsyncImage(url: URL(string: imageUrl), transaction: .init(animation: .spring(response: 1.6))) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                                .progressViewStyle(.circular)
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                        case .failure:
                            Text("Failed fetching image. Make sure to check your data connection and try again.")
                                .foregroundColor(.red)
                        @unknown default:
                            Text("Unknown error. Please try again.")
                                .foregroundColor(.red)
                        }
                    }
                    .frame(width: 300, height: 300)
                    .cornerRadius(10)

                    PickerView(selectedCategory: $selectedCategory, labels: ["Ingredienser", "Bruksanvisning"])

                    if selectedCategory == "Bruksanvisning" {
                        InstructionsStack(instructions: (detailViewModel.recipe.instructions!))
                    }
                    if selectedCategory == "Ingredienser" {
                        IngredientStack(ingredients: (detailViewModel.recipe.ingredients!))
                    }
                    Spacer()
                }
                .onAppear() {
                    detailViewModel.fetchDetails(id: dessertId)
                }
            }
        }
        .preferredColorScheme(isDarkMode ? .dark : .light)
    }
}

