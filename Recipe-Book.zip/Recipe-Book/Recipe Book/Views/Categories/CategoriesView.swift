import SwiftUI

struct CategoryView: View {
    @ObservedObject var viewModel: CategoryViewModel
    var foodVm = FoodViewViewModel(networking: Network())
    
    let gridItem = [GridItem(.fixed(170), spacing: 20), GridItem(.fixed(170), spacing: 20)]
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(UIColor { traitCollection in
                    // Use dynamic colors for light and dark modes
                    if traitCollection.userInterfaceStyle == .dark {
                        return UIColor(red: 0.2, green: 0.3, blue: 0.5, alpha: 1.0) // Darker blue for dark mode
                    } else {
                        return UIColor(red: 0.7, green: 0.8, blue: 1.0, alpha: 1.0) // Light blue for light mode
                    }
                })
                .edgesIgnoringSafeArea(.all)
                
                ScrollView {
                    LazyVGrid(columns: gridItem) {
                        ForEach(viewModel.categories, id: \.self) { category in
                            NavigationLink(destination: FoodsGridView(name: category.name, viewModel: foodVm)) {
                                CategoryCell(imageURL: category.imageURL, name: category.name, sizing: 110)
                            }
                        }
                    }
                }
            }
            .onAppear(perform: viewModel.fetchCategories)
            .navigationBarItems(leading:
                HStack {
                    Spacer()
                    Image("rat")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 700, height: 45)
                    Spacer()
                }
            )
            .navigationBarTitleDisplayMode(.inline)
        }
        .accentColor(.white)
    }
}

