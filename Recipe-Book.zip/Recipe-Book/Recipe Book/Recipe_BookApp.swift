//
//  Recipe_BookApp.swift
//  Recipe Book
//
//  Created by Wali on 1/11/23.
//

import SwiftUI

@main
struct Recipe_BookApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().statusBarHidden(true)
        }
    }
}
