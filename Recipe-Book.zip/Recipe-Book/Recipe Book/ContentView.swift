import SwiftUI

struct ContentView: View {
    @AppStorage("isDarkMode") private var isDarkMode = false

    var categoryVM = CategoryViewModel(networking: Network())
    @State private var showSplash = true

    var body: some View {
        TabView {
            // First Tab (Content View)
            CategoryView(viewModel: categoryVM)
                .tabItem {
                    Image(systemName: "fork.knife.circle.fill")
                    Text("Mine oppskrifter")
                }

            // Second Tab (Settings View)
            VStack {
                Toggle("Dark Mode", isOn: $isDarkMode)
                    .padding()
                    .onChange(of: isDarkMode) { newValue in
                        // Update the preferred color scheme based on the new value of isDarkMode
                        if newValue {
                            UIApplication.shared.windows.first?.rootViewController?.overrideUserInterfaceStyle = .dark
                        } else {
                            UIApplication.shared.windows.first?.rootViewController?.overrideUserInterfaceStyle = .light
                        }
                    }

            }
            .tabItem {
                Image(systemName: "gear")
                Text("Innstillinger")
            }
        }
        .onAppear {
            // You can add any necessary setup code here
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    self.showSplash = false
                }
            }
        }
        // Apply the preferred color scheme to the entire app
        .preferredColorScheme(isDarkMode ? .dark : .light)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
