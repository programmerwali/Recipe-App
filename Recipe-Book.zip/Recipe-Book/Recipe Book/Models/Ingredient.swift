//
//  Ingredient.swift
//  Recipe Book
//
//  Created by Wali on 1/11/23.
//

import Foundation

struct Ingredient: Hashable {
    let name: String
    let measurement: String
}
