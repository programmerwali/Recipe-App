//
//  Category.swift
//  Recipe Book
//
//  Created by Wali on 1/11/23.
//

import Foundation


struct Category: Codable, Hashable {
    let name: String
    let imageURL: String
    
    enum CodingKeys: String, CodingKey {
        case name = "strCategory"
        case imageURL = "strCategoryThumb"
        
    }
}


struct CategoriesResponse: Codable {
    let categories: [Category]
}


